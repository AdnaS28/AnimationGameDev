window.load = drawClock


const canvas = document.getElementById('clockCanvas');
const ctx = canvas.getContext('2d');
const radius = canvas.width / 2;

function drawClock() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    
    ctx.beginPath();
    ctx.arc(radius, radius, radius - 10, 0, 2 * Math.PI);
    ctx.fillStyle = '#fff';
    ctx.fill();
    ctx.lineWidth = 5;
    ctx.strokeStyle = '#333';
    ctx.stroke();

    
    for (let i = 0; i < 12; i++) {
        const angle = (i - 3) * (Math.PI * 2) / 12;
        const x = radius + radius * 0.8 * Math.cos(angle);
        const y = radius + radius * 0.8 * Math.sin(angle);
        ctx.beginPath();
        ctx.arc(x, y, 6, 0, Math.PI * 2);
        ctx.fillStyle = '#333';
        ctx.fill();
    }

    
    const now = new Date();
    const hours = now.getHours() % 12;
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();

    
    const hourAngle = (hours - 3) * (Math.PI * 2) / 12 + (minutes * (Math.PI * 2) / 12 / 60);
    drawHand(hourAngle, radius * 0.5, 8);

    
    const minuteAngle = (minutes - 15) * (Math.PI * 2) / 60 + (seconds * (Math.PI * 2) / 60 / 60);
    drawHand(minuteAngle, radius * 0.7, 4);

    
    const secondAngle = (seconds - 15) * (Math.PI * 2) / 60;
    drawHand(secondAngle, radius * 0.7, 2);

    
    ctx.beginPath();
    ctx.arc(radius, radius, 6, 0, Math.PI * 2);
    ctx.fillStyle = '#333';
    ctx.fill();

    
    ctx.font = '20px Arial';
    ctx.fillStyle = '#880808';
    ctx.textAlign = 'center';
    ctx.fillText('Analog Clock',radius, 80);

    
    setTimeout(drawClock, 1000);
}

function drawHand(angle, length, width) {
    const x = radius + length * Math.cos(angle - Math.PI/2);
    const y = radius + length * Math.sin(angle - Math.PI/2);

    ctx.beginPath();
    ctx.moveTo(radius, radius);
    ctx.lineTo(x, y);
    ctx.lineWidth = width;
    ctx.strokeStyle = '#333';
    ctx.lineCap = 'round';
    ctx.stroke();
}

drawClock();